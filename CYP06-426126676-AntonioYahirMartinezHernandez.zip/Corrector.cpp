/*****************************************************************************************************************
	UNIVERSIDAD NACIONAL AUTONOMA DE MEXICO
	FACULTAD DE ESTUDIOS SUPERIORES -ARAGON-

	Computadoras y programacion.
	(c) Antonio Yahir Martinez Hernandez y 426126676

	Quiso decir: Programa principal de la aplicacion de la distancia de Levenstein.

******************************************************************************************************************/


#include "stdafx.h"
#include <string.h>
#include "corrector.h"
//Funciones publicas del proyecto
/*****************************************************************************************************************
	DICCIONARIO: Esta funcion crea el diccionario completo
	char *	szNombre				:	Nombre del archivo de donde se sacaran las palabras del diccionario
	char	szPalabras[][TAMTOKEN]	:	Arreglo con las palabras completas del diccionario
	int		iEstadisticas[]			:	Arreglo con el numero de veces que aparecen las palabras en el diccionario
	int &	iNumElementos			:	Numero de elementos en el diccionario
******************************************************************************************************************/
void	Diccionario(char* szNombre, char szPalabras[][TAMTOKEN], int iEstadisticas[], int& iNumElementos)

{
	
	int pos = 0;
	while (szNombre[pos] != '\0')
	{
		if (szNombre[pos] == '\n' || szNombre[pos] == '\r')
			szNombre[pos] = '\0';
		pos++;
	}
	FILE* archivo = NULL;
	if (fopen_s(&archivo, szNombre, "r") != 0 || archivo == NULL)
	{
		iNumElementos = 0;
		return;
	}
	iNumElementos = 0;
	char palabra[TAMTOKEN];
	int  longitud = 0;
	int  caracterInt;
	while ((caracterInt = fgetc(archivo)) != EOF)
	{
		unsigned char c = (unsigned char)caracterInt;
		int esValido = 0;
		if (c >= '0' && c <= '9')
		{
			esValido = 1;
		}
		//pedi recomendacion de esta parte porque no lograba entender bien esta parte
		else if (c >= 'A' && c <= 'Z')
		{
			c = (unsigned char)(c - 'A' + 'a');
			esValido = 1;
		}
		else if (c >= 'a' && c <= 'z')
		{
			esValido = 1;
		}
		else if (c == '$' || c == '&' ||
			c == '-' || c == '\'' || c == '"' ||
			c == '!' || c == '/' || c == '#' ||
			c == '?' || c == ':' || c == '+' ||
			c == '%' || c == '@' || c == '=' ||
			c == '_' || c == '[' || c == ']')
		{
			esValido = 1;
		}
		else if (c >= 128)
		{
			esValido = 1;
		}
		if (esValido)
		{
			if (longitud < TAMTOKEN - 1)
			{
				palabra[longitud] = (char)c;
				longitud++;
			}
		}
		else
		{
			if (longitud > 0)
			{
				palabra[longitud] = '\0';
				if (palabra[0] != '\0')
				{
					int repetida = -1;
					for (int i = 0; i < iNumElementos; i++)
					{
						if (strcmp(szPalabras[i], palabra) == 0 && repetida == -1)
						{
							repetida = i;
						}
					}

					if (repetida >= 0)
					{
						iEstadisticas[repetida]++;
					}
					else if (iNumElementos < NUMPALABRAS)
					{
						strcpy_s(szPalabras[iNumElementos], TAMTOKEN, palabra);
						iEstadisticas[iNumElementos] = 1;
						iNumElementos++;
					}
				}

				longitud = 0;
			}
		}
	}
	if (longitud > 0)
	{
		palabra[longitud] = '\0';

		if (palabra[0] != '\0')
		{
			int repetida = -1;
			for (int i = 0; i < iNumElementos; i++)
			{
				if (strcmp(szPalabras[i], palabra) == 0)
				{
					repetida = i;
				}
			}
			if (repetida >= 0)
			{
				iEstadisticas[repetida]++;
			}
			else if (iNumElementos < NUMPALABRAS)
			{
				strcpy_s(szPalabras[iNumElementos], TAMTOKEN, palabra);
				iEstadisticas[iNumElementos] = 1;
				iNumElementos++;
			}
		}
	}
	fclose(archivo);
	for (int i = 0; i < iNumElementos - 1; i++)
	{
		for (int j = i + 1; j < iNumElementos; j++)
		{
			if (strcmp(szPalabras[j], szPalabras[i]) < 0)
			{
				char temp[TAMTOKEN];
				strcpy_s(temp, TAMTOKEN, szPalabras[i]);
				strcpy_s(szPalabras[i], TAMTOKEN, szPalabras[j]);
				strcpy_s(szPalabras[j], TAMTOKEN, temp);

				int tmpF = iEstadisticas[i];
				iEstadisticas[i] = iEstadisticas[j];
				iEstadisticas[j] = tmpF;
			}
		}
	}

}


/*****************************************************************************************************************
	ListaCandidatas: Esta funcion recupera desde el diccionario las palabras validas y su peso
	Regresa las palabras ordenadas por su peso
	char	szPalabrasSugeridas[][TAMTOKEN],	//Lista de palabras clonadas
	int		iNumSugeridas,						//Lista de palabras clonadas
	char	szPalabras[][TAMTOKEN],				//Lista de palabras del diccionario
	int		iEstadisticas[],					//Lista de las frecuencias de las palabras
	int		iNumElementos,						//Numero de elementos en el diccionario
	char	szListaFinal[][TAMTOKEN],			//Lista final de palabras a sugerir
	int		iPeso[],							//Peso de las palabras en la lista final
	int &	iNumLista)							//Numero de elementos en la szListaFinal
******************************************************************************************************************/
void	ListaCandidatas(
	char	szPalabrasSugeridas[][TAMTOKEN],	//Lista de palabras clonadas
	int		iNumSugeridas,						//Lista de palabras clonadas
	char	szPalabras[][TAMTOKEN],				//Lista de palabras del diccionario
	int		iEstadisticas[],					//Lista de las frecuencias de las palabras
	int		iNumElementos,						//Numero de elementos en el diccionario
	char	szListaFinal[][TAMTOKEN],			//Lista final de palabras a sugerir
	int		iPeso[],							//Peso de las palabras en la lista final
	int& iNumLista)							//Numero de elementos en la szListaFinal


{
	int i, j, k;
	iNumLista = 0;
	i = 0;
	while (i < iNumSugeridas && iNumLista < NUMPALABRAS)
	{
		j = 0;
		while (j < iNumElementos && iNumLista < NUMPALABRAS)
		{
			if (strcmp(szPalabrasSugeridas[i], szPalabras[j]) == 0)
			{
				int palabrarepetida = 0;
				k = 0;
				while (k < iNumLista)
				{
					if (strcmp(szListaFinal[k], szPalabras[j]) == 0)
					{
						palabrarepetida = 1;
					}
					k++;
				}
				if (palabrarepetida == 0)
				{
					strcpy_s(szListaFinal[iNumLista], TAMTOKEN, szPalabras[j]);
					iPeso[iNumLista] = iEstadisticas[j];
					iNumLista++;
				}
			}
			j++;
		}
		i++;
	}
	for (i = 0; i < iNumLista - 1; i++)
	{
		for (j = i + 1; j < iNumLista; j++)
		{
			if (iPeso[j] > iPeso[i])
			{
				int temporal = iPeso[i];
				iPeso[i] = iPeso[j];
				iPeso[j] = temporal;
				char temporalpalabra[TAMTOKEN];
				strcpy_s(temporalpalabra, szListaFinal[i]);
				strcpy_s(szListaFinal[i], szListaFinal[j]);
				strcpy_s(szListaFinal[j], temporalpalabra);
			}
		}
	}
}
/*****************************************************************************************************************
	ClonaPalabras: toma una palabra y obtiene todas las combinaciones y permutaciones requeridas por el metodo
	char *	szPalabraLeida,						// Palabra a clonar
	char	szPalabrasSugeridas[][TAMTOKEN], 	//Lista de palabras clonadas
	int &	iNumSugeridas)						//Numero de elementos en la lista
******************************************************************************************************************/
void	ClonaPalabras(
	char* szPalabraLeida,						// Palabra a clonar
	char	szPalabrasSugeridas[][TAMTOKEN], 	//Lista de palabras clonadas
	int& iNumSugeridas)						//Numero de elementos en la lista
{
	const char abcdario[] = "abcdefghijklmn�opqrstuvwxyz�����";

	char palabra_original[TAMTOKEN];
	char palabra[TAMTOKEN];
	char candidata[TAMTOKEN];
	int i, j, k, pl, pos;
	strncpy_s(palabra_original, szPalabraLeida, TAMTOKEN - 1);
	palabra_original[TAMTOKEN - 1] = '\0';

	strncpy_s(palabra, palabra_original, TAMTOKEN - 1);
	palabra[TAMTOKEN - 1] = '\0';

	k = (int)strlen(palabra_original);
	iNumSugeridas = 0;
	if (iNumSugeridas < NUMPALABRAS)
	{
		strcpy_s(szPalabrasSugeridas[iNumSugeridas], TAMTOKEN, palabra_original);
		iNumSugeridas++;
	}
	for (i = 0; i < k && iNumSugeridas < NUMPALABRAS; i++)
	{
		char original = palabra_original[i];

		for (j = 0; abcdario[j] != '\0' && iNumSugeridas < NUMPALABRAS; j++)
		{

			strncpy_s(palabra, palabra_original, TAMTOKEN - 1);
			palabra[TAMTOKEN - 1] = '\0';
			palabra[i] = abcdario[j];

			if (iNumSugeridas < NUMPALABRAS)
			{
				strcpy_s(szPalabrasSugeridas[iNumSugeridas], TAMTOKEN, palabra);
				iNumSugeridas++;
			}
		}
	}
	for (i = 0; i < k - 1 && iNumSugeridas < NUMPALABRAS; i++)
	{
		strncpy_s(palabra, palabra_original, TAMTOKEN - 1);
		palabra[TAMTOKEN - 1] = '\0';
		char tmp = palabra[i];
		palabra[i] = palabra[i + 1];
		palabra[i + 1] = tmp;

		if (iNumSugeridas < NUMPALABRAS)
		{
			strcpy_s(szPalabrasSugeridas[iNumSugeridas], TAMTOKEN, palabra);
			iNumSugeridas++;
		}
	}
	for (i = 0; i < k && iNumSugeridas < NUMPALABRAS; i++)
	{
		pos = 0;
		for (j = 0; j < k && pos < TAMTOKEN - 1; j++)
		{
			if (j != i)
			{
				candidata[pos] = palabra_original[j];
				pos++;
			}
		}
		if (pos == 0)
			continue;

		candidata[pos] = '\0';

		if (iNumSugeridas < NUMPALABRAS)
		{
			strcpy_s(szPalabrasSugeridas[iNumSugeridas], TAMTOKEN, candidata);
			iNumSugeridas++;
		}
	}
	if (k + 1 < TAMTOKEN)
	{
		for (i = 0; i <= k && iNumSugeridas < NUMPALABRAS; i++)
		{
			for (j = 0; abcdario[j] != '\0' && iNumSugeridas < NUMPALABRAS; j++)
			{
				pos = 0;
				for (pl = 0; pl < i && pos < TAMTOKEN - 1; pl++)
				{
					candidata[pos] = palabra_original[pl];
					pos++;
				}
				if (pos < TAMTOKEN - 1)
				{
					candidata[pos] = abcdario[j];
					pos++;
				}
				for (pl = i; pl < k && pos < TAMTOKEN - 1; pl++)
				{
					candidata[pos] = palabra_original[pl];
					pos++;
				}
				candidata[pos] = '\0';

				if (iNumSugeridas < NUMPALABRAS)
				{
					strcpy_s(szPalabrasSugeridas[iNumSugeridas], TAMTOKEN, candidata);
					iNumSugeridas++;
				}
			}
		}
	}
	for (i = 0; i < iNumSugeridas - 1; i++)
	{
		for (j = i + 1; j < iNumSugeridas; j++)
		{
			if (strcmp(szPalabrasSugeridas[j], szPalabrasSugeridas[i]) < 0)
			{
				char tmp2[TAMTOKEN];
				strcpy_s(tmp2, szPalabrasSugeridas[i]);
				strcpy_s(szPalabrasSugeridas[i], szPalabrasSugeridas[j]);
				strcpy_s(szPalabrasSugeridas[j], tmp2);
			}
		}
	}
}