
#include <stdio.h>

int main()
{
	int ancho, altura, p1, p2, c3, c4;
	float x, y, x1, y1;

	scanf_s("%i %i %f %f %f %f", &ancho, &altura, &x, &y, &x1, &y1);
	p1 = (int)(x * ancho);
	p2 = (int)(y * altura);
	c3 = (int)(x1 * ancho) + p1;
	c4 = (int)(y1 * altura) + p2;
	printf("%i %i %5.2f %5.2f %5.2f %5.2f %i %i %i %i", ancho, altura, x, y, x1, y1, p1, p2, c3, c4);
	return 0;
}
